/* DO NOT REMOVE INCLUDES - Do NOT add your own */
#include "part2-calendar.h"

/* GLOBAL CALENDAR ARRAY */
date calendar_2021[NUM_DAYS];

/**
 * @brief Initialize the entire calendar
 *            Set each date in calendar_2021 to the correct month, day, and year.
 *            Also, set each date's num_events value to 0
 */
void initialize_calendar(void){
    
    return;
}

/**
 * @brief Compare the times of two events and determine if they 'overlap'
 *             See PDF section - Calendar Conditions - for how we define 'overlap'
 * 
 * @param e1 event 1
 * @param e2 event 2
 * @return int SUCCESS or ERROR
 */
int check_event_overlap(event e1, event e2){
    
    /* Remove once the function is implemented */
    UNUSED(e1);
    UNUSED(e2);


    return ERROR;
}

/**
 * @brief Add new event to the calendar on the specified date.
 *             Remember event times canNOT overlap
 *             Consider using your check_event_overlap() function
 * 
 * @param d used to locate the date's index in calendar_2021
 * @param new_event event being added
 * @return int SUCCESS or ERROR
 */
int add_calendar_event(date d, event new_event){
    
    /* Remove once the function is implemented */
    UNUSED(d);
    UNUSED(new_event);


    return ERROR;
}

/**
 * @brief Remove an event from the specified date.
 *             Remember to shift any subsequent events 'up' in the array
 * 
 *  EX:
 *      Remove Event at index 2:
 *          - [e1, e2, e3, e4, e5]
 *          - [e1, e2, e4, e5]
 * 
 * @param d used to locate the date's index in calendar_2021
 * @param event_index index of the event to remove
 * @return int SUCCESS or ERROR
 */
int remove_calendar_event(date d, int event_index){
    
    /* Remove once the function is implemented */
    UNUSED(d);
    UNUSED(event_index);


    return ERROR;
}

/**
 * @brief Modify a specific event's start time and end time
 * 
 * @param d used to locate the date's index in calendar_2021
 * @param event_index index of the event to modify
 * @param start new event start time
 * @param end new event end time
 * @return int SUCCESS or ERROR
 */
int change_event_time(date d, int event_index, time start, time end){

    /* Remove once the function is implemented */
    UNUSED(d);
    UNUSED(event_index);
    UNUSED(start);
    UNUSED(end);


    return ERROR;
}

/**
 * @brief Modify a specifc event's description string
 * 
 * @param d used to locate the date's index in calendar_2021
 * @param event_index index of the event to modify
 * @param description new string to copy into the event's description
 * @return int SUCCESS or ERROR
 */
int change_event_description(date d, int event_index, char description[SIZE_DESCRIPTION]){
    
    /* Remove once the function is implemented */
    UNUSED(d);
    UNUSED(event_index);
    UNUSED(description);


    return ERROR;
}

/**
 * @brief Sort a date's event array by start time (earliest time to latest time)
 * 
 * @param d used to locate the date's index in calendar_2021
 */
void sort_events(date d){

    /* Remove once the function is implemented */
    UNUSED(d);
}

/**
 * @brief Destroy the calendar - set each calendar date month, day, year, and num_events to 0
 */
void destroy_calendar(void){
    return;
}
