/* DO NOT REMOVE INCLUDES - Do NOT add your own */
#include "part1-porting_assembly.h"
#include "part2-calendar.h"

int main(void) {

    /* Call your part1 and part2 functions here if you would like to test them yourself */
    int test_value = compare(2, 3);
    printf("Expected Return Value: -1\nActual Return Value: %d\n", test_value);
    
    return 0;
}

